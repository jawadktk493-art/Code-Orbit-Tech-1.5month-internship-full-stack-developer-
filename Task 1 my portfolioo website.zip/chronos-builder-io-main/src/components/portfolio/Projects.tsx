import { motion } from "framer-motion";
import { Github, ArrowUpRight } from "lucide-react";
import { SectionHeader } from "./Section";
import studypro from "@/assets/studypro.jpg";
import transittrack from "@/assets/transittrack.jpg";
import buildspace from "@/assets/buildspace.jpg";

const projects = [
  {
    name: "StudyPro",
    image: studypro,
    description:
      "A productivity-focused Android app helping students manage academics with digital notes, scheduling, study organization, and an integrated browser.",
    tags: ["Android Studio", "Kotlin", "XML"],
  },
  {
    name: "TransitTrack",
    image: transittrack,
    description:
      "A modern transit management system with a live fleet dashboard monitoring vehicles, drivers, routes, fares, and operational status in real time.",
    tags: ["Android Studio", "Kotlin", "XML"],
  },
  {
    name: "BuildSpace",
    image: buildspace,
    description:
      "A responsive workspace discovery landing page showcasing responsive design, interactive UI components, and clean frontend architecture.",
    tags: ["HTML", "CSS", "JavaScript"],
  },
];

export function Projects() {
  return (
    <section id="projects" className="relative px-4 py-24">
      <div className="mx-auto max-w-6xl">
        <SectionHeader
          eyebrow="Selected work"
          title={<>Projects I've <span className="text-gradient">built</span></>}
          description="Real-world projects where I've turned concepts into shipped products."
        />

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {projects.map((p, i) => (
            <motion.article
              key={p.name}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.6, delay: i * 0.1 }}
              whileHover={{ y: -8 }}
              className="group glass relative flex flex-col overflow-hidden rounded-2xl transition-all hover:border-white/20"
            >
              <div className="relative aspect-[16/10] overflow-hidden">
                <img
                  src={p.image}
                  alt={`${p.name} preview`}
                  width={1024}
                  height={768}
                  loading="lazy"
                  className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-card via-card/30 to-transparent opacity-90" />
              </div>

              <div className="flex flex-1 flex-col p-6">
                <h3 className="font-display text-xl font-semibold">{p.name}</h3>
                <p className="mt-2 flex-1 text-sm text-muted-foreground">{p.description}</p>

                <div className="mt-4 flex flex-wrap gap-1.5">
                  {p.tags.map((t) => (
                    <span
                      key={t}
                      className="rounded-full border border-white/10 bg-white/[0.04] px-2.5 py-0.5 font-mono text-[11px] text-muted-foreground"
                    >
                      {t}
                    </span>
                  ))}
                </div>

                <div className="mt-5 flex items-center gap-2">
                  <a
                    href="#"
                    className="inline-flex flex-1 items-center justify-center gap-1.5 rounded-lg bg-[image:var(--gradient-primary)] px-3 py-2 text-xs font-semibold text-primary-foreground transition-transform hover:scale-[1.03]"
                  >
                    View Details <ArrowUpRight className="h-3.5 w-3.5" />
                  </a>
                  <a
                    href="#"
                    className="inline-flex items-center justify-center gap-1.5 rounded-lg border border-white/15 px-3 py-2 text-xs font-semibold text-foreground transition-colors hover:border-[color:var(--accent-cyan)] hover:text-[color:var(--accent-cyan)]"
                  >
                    <Github className="h-3.5 w-3.5" /> Source
                  </a>
                </div>
              </div>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  );
}