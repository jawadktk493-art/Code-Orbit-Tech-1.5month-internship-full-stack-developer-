import { motion } from "framer-motion";
import { GraduationCap, BookOpen } from "lucide-react";
import { SectionHeader } from "./Section";

const items = [
  {
    icon: GraduationCap,
    title: "Bachelor of Science in Computer Science",
    org: "City University of Science and Information Technology (CUSIT)",
    period: "Expected Graduation — 2027",
    desc: "Studying core CS fundamentals, software engineering, web development, and database systems while building real-world projects on the side.",
  },
  {
    icon: BookOpen,
    title: "Self-Taught Full Stack Journey",
    org: "Ongoing — Independent Learning",
    period: "Continuous",
    desc: "Exploring modern frontend frameworks, backend architectures, databases, and UI design through hands-on projects and online resources.",
  },
];

export function Education() {
  return (
    <section id="education" className="relative px-4 py-24">
      <div className="mx-auto max-w-4xl">
        <SectionHeader
          eyebrow="Education"
          title={<>My learning <span className="text-gradient">timeline</span></>}
        />

        <div className="relative">
          <div
            className="absolute left-5 top-2 bottom-2 w-px md:left-1/2"
            style={{ background: "linear-gradient(to bottom, transparent, oklch(0.68 0.22 300 / 0.6), transparent)" }}
          />
          <div className="space-y-10">
            {items.map((item, i) => (
              <motion.div
                key={item.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-60px" }}
                transition={{ duration: 0.6, delay: i * 0.1 }}
                className={`relative flex items-start gap-6 md:grid md:grid-cols-2 md:gap-12 ${
                  i % 2 ? "md:[&>*:first-child]:order-2" : ""
                }`}
              >
                <div className={`hidden md:block ${i % 2 ? "md:text-left" : "md:text-right"}`}>
                  <p className="font-mono text-xs uppercase tracking-wider text-[color:var(--accent-cyan)]">
                    {item.period}
                  </p>
                </div>
                <div className="relative pl-14 md:pl-12">
                  <div className="absolute left-0 top-1 grid h-10 w-10 place-items-center rounded-full bg-[image:var(--gradient-primary)] text-primary-foreground shadow-[0_0_24px_-4px_oklch(0.68_0.22_300/0.6)] md:left-1/2 md:-translate-x-1/2">
                    <item.icon className="h-5 w-5" />
                  </div>
                  <div className="glass rounded-2xl p-6">
                    <p className="md:hidden font-mono text-[11px] uppercase tracking-wider text-[color:var(--accent-cyan)]">
                      {item.period}
                    </p>
                    <h3 className="mt-1 font-display text-lg font-semibold">{item.title}</h3>
                    <p className="mt-1 text-sm text-muted-foreground">{item.org}</p>
                    <p className="mt-3 text-sm text-muted-foreground/90">{item.desc}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}