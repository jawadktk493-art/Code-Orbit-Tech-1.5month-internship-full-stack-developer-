import { ArrowUp, Code2 } from "lucide-react";

export function Footer() {
  return (
    <footer className="relative border-t border-white/5 px-4 py-10">
      <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-6 sm:flex-row">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <span className="grid h-7 w-7 place-items-center rounded-md bg-[image:var(--gradient-primary)] text-primary-foreground">
            <Code2 className="h-3.5 w-3.5" />
          </span>
          <span>
            © {new Date().getFullYear()} <span className="text-foreground font-medium">Jawad Zahid</span>. Crafted with care.
          </span>
        </div>
        <a
          href="#home"
          className="group inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.03] px-4 py-2 text-xs font-medium text-foreground transition-all hover:border-[color:var(--accent-cyan)]/60 hover:bg-white/[0.06]"
        >
          Back to top
          <ArrowUp className="h-3.5 w-3.5 transition-transform group-hover:-translate-y-0.5" />
        </a>
      </div>
    </footer>
  );
}