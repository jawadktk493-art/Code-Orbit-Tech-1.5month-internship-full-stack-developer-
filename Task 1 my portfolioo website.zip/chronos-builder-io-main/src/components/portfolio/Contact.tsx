import { useState } from "react";
import { motion } from "framer-motion";
import { Github, Linkedin, Mail, Phone, Send, Check } from "lucide-react";
import { SectionHeader } from "./Section";

const socials = [
  { icon: Github, label: "GitHub", value: "jawadktk493-art", href: "https://github.com/jawadktk493-art/full-stack-project" },
  { icon: Linkedin, label: "LinkedIn", value: "Jawad Zahid", href: "https://www.linkedin.com/in/jawad-zahid-09938a360?utm_source=share_via&utm_content=profile&utm_medium=member_android" },
  { icon: Mail, label: "Email", value: "jawadktk493@gmail.com", href: "mailto:jawadktk493@gmail.com" },
  { icon: Phone, label: "Phone", value: "0336 9006456", href: "tel:+923369006456" },
];

export function Contact() {
  const [sent, setSent] = useState(false);
  return (
    <section id="contact" className="relative px-4 py-24">
      <div className="mx-auto max-w-5xl">
        <SectionHeader
          eyebrow="Get in touch"
          title={<>Let's build something <span className="text-gradient">great</span></>}
          description="Have a project, internship, or idea in mind? Drop me a message — I'll get back to you soon."
        />

        <div className="grid gap-6 lg:grid-cols-[1fr_1.3fr]">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="glass rounded-3xl p-8"
          >
            <h3 className="font-display text-xl font-semibold">Contact info</h3>
            <p className="mt-2 text-sm text-muted-foreground">
              I'm always open to discussing new opportunities, collaborations, or just a friendly chat about tech.
            </p>
            <div className="mt-6 space-y-3">
              {socials.map((s) => (
                <a
                  key={s.label}
                  href={s.href}
                  target={s.href.startsWith("http") ? "_blank" : undefined}
                  rel={s.href.startsWith("http") ? "noopener noreferrer" : undefined}
                  className="group flex items-center gap-3 rounded-xl border border-white/5 bg-white/[0.02] p-3 transition-all hover:border-[color:var(--accent-cyan)]/40 hover:bg-white/[0.04]"
                >
                  <span className="grid h-10 w-10 shrink-0 place-items-center rounded-lg bg-[image:var(--gradient-primary)] text-primary-foreground transition-transform group-hover:scale-110">
                    <s.icon className="h-4 w-4" />
                  </span>
                  <div className="flex flex-col">
                    <span className="text-sm font-medium">{s.label}</span>
                    <span className="text-xs text-muted-foreground">{s.value}</span>
                  </div>
                </a>
              ))}
            </div>
          </motion.div>

          <motion.form
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            onSubmit={(e) => {
              e.preventDefault();
              setSent(true);
              setTimeout(() => setSent(false), 3000);
              (e.currentTarget as HTMLFormElement).reset();
            }}
            className="glass rounded-3xl p-8"
          >
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Name" name="name" placeholder="Your name" />
              <Field label="Email" name="email" type="email" placeholder="you@email.com" />
            </div>
            <div className="mt-4">
              <Field label="Subject" name="subject" placeholder="What's this about?" />
            </div>
            <div className="mt-4">
              <label className="font-mono text-[11px] uppercase tracking-wider text-muted-foreground">Message</label>
              <textarea
                required
                name="message"
                rows={5}
                placeholder="Tell me a bit about your project..."
                className="mt-1.5 w-full resize-none rounded-xl border border-white/10 bg-white/[0.03] px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground/60 outline-none transition-colors focus:border-[color:var(--accent-cyan)]"
              />
            </div>
            <button
              type="submit"
              className="mt-5 inline-flex w-full items-center justify-center gap-2 rounded-xl bg-[image:var(--gradient-primary)] px-6 py-3 text-sm font-semibold text-primary-foreground shadow-[0_12px_40px_-12px_oklch(0.68_0.22_300/0.7)] transition-transform hover:scale-[1.01] sm:w-auto"
            >
              {sent ? (
                <>
                  <Check className="h-4 w-4" /> Message sent
                </>
              ) : (
                <>
                  <Send className="h-4 w-4" /> Send Message
                </>
              )}
            </button>
          </motion.form>
        </div>
      </div>
    </section>
  );
}

function Field({
  label,
  name,
  type = "text",
  placeholder,
}: {
  label: string;
  name: string;
  type?: string;
  placeholder?: string;
}) {
  return (
    <div>
      <label className="font-mono text-[11px] uppercase tracking-wider text-muted-foreground">{label}</label>
      <input
        required
        name={name}
        type={type}
        placeholder={placeholder}
        className="mt-1.5 w-full rounded-xl border border-white/10 bg-white/[0.03] px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground/60 outline-none transition-colors focus:border-[color:var(--accent-cyan)]"
      />
    </div>
  );
}