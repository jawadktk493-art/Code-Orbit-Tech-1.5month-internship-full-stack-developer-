import { useEffect, useRef, useState } from "react";
import { motion, useInView } from "framer-motion";
import { Trophy, Rocket, Heart, Cpu } from "lucide-react";

const stats = [
  { icon: Rocket, label: "Projects Completed", value: 3, suffix: "+" },
  { icon: Trophy, label: "Years of Learning", value: 3, suffix: "+" },
  { icon: Heart, label: "Passion Level", value: 100, suffix: "%" },
  { icon: Cpu, label: "Technologies Explored", value: 15, suffix: "+" },
];

function Counter({ to, suffix }: { to: number; suffix: string }) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, margin: "-50px" });
  const [n, setN] = useState(0);
  useEffect(() => {
    if (!inView) return;
    const start = performance.now();
    const dur = 1600;
    let raf = 0;
    const tick = (t: number) => {
      const p = Math.min(1, (t - start) / dur);
      setN(Math.round(to * (1 - Math.pow(1 - p, 3))));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [inView, to]);
  return (
    <span ref={ref} className="font-display text-4xl font-bold sm:text-5xl text-gradient">
      {n}
      {suffix}
    </span>
  );
}

export function Achievements() {
  return (
    <section className="relative px-4 py-16">
      <div className="mx-auto max-w-6xl">
        <div className="glass-strong rounded-3xl p-8 sm:p-10">
          <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
            {stats.map((s, i) => (
              <motion.div
                key={s.label}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: i * 0.08 }}
                className="text-center"
              >
                <div
                  className="mx-auto grid h-12 w-12 place-items-center rounded-2xl text-primary-foreground"
                  style={{ background: "var(--gradient-primary)" }}
                >
                  <s.icon className="h-5 w-5" />
                </div>
                <div className="mt-4">
                  <Counter to={s.value} suffix={s.suffix} />
                </div>
                <p className="mt-1 text-sm text-muted-foreground">{s.label}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}