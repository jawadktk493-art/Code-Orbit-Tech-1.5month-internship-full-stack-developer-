import { motion } from "framer-motion";
import { Lightbulb, GraduationCap, Sparkles, Code2 } from "lucide-react";
import { SectionHeader } from "./Section";

const strengths = [
  { icon: Lightbulb, label: "Problem Solving", desc: "Breaking down complex challenges into elegant solutions." },
  { icon: GraduationCap, label: "Continuous Learning", desc: "Always exploring new technologies and patterns." },
  { icon: Sparkles, label: "Creativity", desc: "Turning ideas into delightful user experiences." },
];

const info = [
  { k: "Name", v: "Jawad Zahid" },
  { k: "Role", v: "Full Stack Developer" },
  { k: "Education", v: "BSc Computer Science" },
  { k: "University", v: "CUSIT" },
  { k: "Graduation", v: "2027" },
  { k: "Focus", v: "Web Applications" },
];

export function About() {
  return (
    <section id="about" className="relative px-4 py-24">
      <div className="mx-auto max-w-6xl">
        <SectionHeader
          eyebrow="About me"
          title={<>The story <span className="text-gradient">behind the code</span></>}
        />

        <div className="grid gap-8 lg:grid-cols-[1fr_1.2fr]">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="glass rounded-3xl p-8"
          >
            <div className="flex items-center gap-3">
              <span className="grid h-10 w-10 place-items-center rounded-xl bg-[image:var(--gradient-primary)] text-primary-foreground">
                <Code2 className="h-5 w-5" />
              </span>
              <h3 className="font-display text-xl font-semibold">Who I am</h3>
            </div>
            <p className="mt-5 text-base leading-relaxed text-muted-foreground">
              I'm <span className="text-foreground font-medium">Jawad Zahid</span>, a Bachelor of Computer Science student at <span className="text-foreground">CUSIT</span>, expected to graduate in <span className="text-foreground">2027</span>. I'm passionate about Full Stack Web Development and enjoy learning new technologies while building innovative, user-friendly applications.
            </p>
            <p className="mt-4 text-base leading-relaxed text-muted-foreground">
              My goal is to become a skilled Full Stack Developer who creates impactful digital products. I love solving problems, refining my craft, and turning ideas into modern, functional websites.
            </p>

            <div className="mt-6 grid grid-cols-2 gap-3">
              {info.map((row) => (
                <div key={row.k} className="rounded-xl border border-white/5 bg-white/[0.02] p-3">
                  <p className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground">{row.k}</p>
                  <p className="mt-1 text-sm font-medium text-foreground">{row.v}</p>
                </div>
              ))}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="grid gap-4"
          >
            {strengths.map((s, i) => (
              <motion.div
                key={s.label}
                whileHover={{ y: -4 }}
                className="group glass rounded-2xl p-6 transition-all hover:border-white/20 hover:bg-white/[0.04]"
              >
                <div className="flex items-start gap-4">
                  <div
                    className="grid h-12 w-12 shrink-0 place-items-center rounded-xl text-primary-foreground transition-transform group-hover:scale-110"
                    style={{ background: `linear-gradient(135deg, oklch(0.65 0.2 ${255 + i * 25}), oklch(0.75 0.18 ${200 + i * 25}))` }}
                  >
                    <s.icon className="h-5 w-5" />
                  </div>
                  <div className="min-w-0">
                    <h4 className="font-display text-lg font-semibold">{s.label}</h4>
                    <p className="mt-1 text-sm text-muted-foreground">{s.desc}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
}