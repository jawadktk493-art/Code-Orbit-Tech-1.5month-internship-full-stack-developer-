import { motion } from "framer-motion";
import { Typewriter } from "react-simple-typewriter";
import { Download, ArrowRight, Mail, Sparkles } from "lucide-react";
import profileAsset from "@/assets/jawad-portrait.jpg.asset.json";

const profileImg = profileAsset.url;

const orbitIcons = [
  { label: "JS", color: "oklch(0.85 0.18 90)" },
  { label: "TS", color: "oklch(0.65 0.18 245)" },
  { label: "PHP", color: "oklch(0.7 0.15 280)" },
  { label: "SQL", color: "oklch(0.78 0.15 200)" },
  { label: "Git", color: "oklch(0.7 0.2 30)" },
  { label: "CSS", color: "oklch(0.7 0.18 230)" },
  { label: "HTML", color: "oklch(0.7 0.2 40)" },
  { label: "BS", color: "oklch(0.7 0.2 300)" },
];

export function Hero() {
  return (
    <section id="home" className="relative flex min-h-screen items-center px-4 pt-32 pb-16">
      <div className="mx-auto grid w-full max-w-6xl gap-12 lg:grid-cols-[1.1fr_0.9fr] lg:items-center">
        {/* LEFT */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="text-center lg:text-left"
        >
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="inline-flex items-center gap-2 rounded-full glass px-4 py-1.5 text-xs font-medium text-muted-foreground"
          >
            <Sparkles className="h-3.5 w-3.5 text-[color:var(--accent-cyan)]" />
            Available for opportunities
          </motion.div>

          <p className="mt-6 font-mono text-sm text-[color:var(--accent-cyan)]">
            Hello, I'm
          </p>
          <h1 className="mt-2 font-display text-5xl font-bold leading-[1.05] tracking-tight sm:text-6xl lg:text-7xl">
            Jawad <span className="text-gradient">Zahid</span>
          </h1>
          <h2 className="mt-3 font-display text-2xl font-semibold text-muted-foreground sm:text-3xl">
            Full Stack Developer
          </h2>

          <div className="mt-5 h-8 font-mono text-base text-foreground/90 sm:text-lg">
            <span className="cursor-blink">
              <Typewriter
                words={[
                  "Building modern, responsive web applications.",
                  "Turning ideas into interactive experiences.",
                  "Creating scalable web solutions.",
                ]}
                loop
                cursor={false}
                typeSpeed={55}
                deleteSpeed={35}
                delaySpeed={1800}
              />
            </span>
          </div>

          <p className="mx-auto mt-6 max-w-xl text-base text-muted-foreground lg:mx-0">
            CS student at CUSIT (2027) passionate about crafting clean,
            performant, and user-friendly digital products from front to back.
          </p>

          <div className="mt-8 flex flex-wrap items-center justify-center gap-3 lg:justify-start">
            <a
              href="#contact"
              className="group inline-flex items-center gap-2 rounded-xl bg-[image:var(--gradient-primary)] px-6 py-3 text-sm font-semibold text-primary-foreground shadow-[0_12px_40px_-10px_oklch(0.68_0.22_300/0.7)] transition-all hover:scale-[1.03] hover:shadow-[0_16px_50px_-8px_oklch(0.68_0.22_300/0.85)]"
            >
              Hire Me
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </a>
            <a
              href="#projects"
              className="inline-flex items-center gap-2 rounded-xl glass px-6 py-3 text-sm font-semibold text-foreground transition-all hover:bg-white/10"
            >
              View Projects
            </a>
            <a
              href="#"
              className="inline-flex items-center gap-2 rounded-xl border border-white/15 px-6 py-3 text-sm font-semibold text-foreground transition-all hover:border-[color:var(--accent-cyan)] hover:text-[color:var(--accent-cyan)]"
            >
              <Download className="h-4 w-4" />
              Download CV
            </a>
            <a
              href="#contact"
              className="inline-flex items-center gap-2 rounded-xl px-4 py-3 text-sm font-semibold text-muted-foreground transition-colors hover:text-foreground"
            >
              <Mail className="h-4 w-4" />
              Let's Talk
            </a>
          </div>
        </motion.div>

        {/* RIGHT */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1, ease: "easeOut", delay: 0.2 }}
          className="relative mx-auto aspect-square w-[18rem] sm:w-[22rem] lg:w-[26rem]"
        >
          {/* outer glow ring */}
          <div className="absolute inset-0 animate-pulse-glow rounded-full" />
          <motion.div
            className="absolute inset-0 rounded-full p-[3px]"
            style={{ background: "var(--gradient-primary)" }}
            animate={{ rotate: 360 }}
            transition={{ duration: 18, repeat: Infinity, ease: "linear" }}
          >
            <div className="h-full w-full rounded-full bg-background" />
          </motion.div>
          <div className="absolute inset-4 overflow-hidden rounded-full ring-1 ring-white/10">
            <img
              src={profileImg}
              alt="Jawad Zahid portrait"
              width={768}
              height={768}
              className="h-full w-full object-cover"
            />
          </div>

          {/* orbit icons */}
          {orbitIcons.map((icon, i) => {
            const angle = (i / orbitIcons.length) * 360;
            return (
              <motion.div
                key={icon.label}
                className="absolute left-1/2 top-1/2 grid h-12 w-12 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-xl glass-strong text-xs font-bold font-mono"
                style={{ color: icon.color, boxShadow: `0 0 20px -4px ${icon.color}` }}
                animate={{
                  x: Math.cos((angle * Math.PI) / 180) * 170,
                  y: Math.sin((angle * Math.PI) / 180) * 170,
                }}
                transition={{ duration: 0 }}
              >
                <motion.span
                  animate={{ y: [0, -6, 0] }}
                  transition={{ duration: 3 + (i % 3), repeat: Infinity, delay: i * 0.2 }}
                >
                  {icon.label}
                </motion.span>
              </motion.div>
            );
          })}
        </motion.div>
      </div>
    </section>
  );
}