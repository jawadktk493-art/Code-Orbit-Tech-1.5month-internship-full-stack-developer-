import { motion } from "framer-motion";
import { SectionHeader } from "./Section";
import { Code2, Server, Cpu, Database, Wrench, Palette } from "lucide-react";

type Skill = { name: string; level: number };

const groups: { title: string; icon: typeof Code2; color: string; skills: Skill[] }[] = [
  {
    title: "Frontend",
    icon: Code2,
    color: "oklch(0.7 0.18 230)",
    skills: [
      { name: "HTML5", level: 92 },
      { name: "CSS3", level: 88 },
      { name: "JavaScript", level: 82 },
      { name: "Bootstrap", level: 85 },
    ],
  },
  {
    title: "Backend",
    icon: Server,
    color: "oklch(0.68 0.22 300)",
    skills: [{ name: "PHP", level: 78 }],
  },
  {
    title: "Languages",
    icon: Cpu,
    color: "oklch(0.65 0.2 255)",
    skills: [
      { name: "C++", level: 80 },
      { name: "Java", level: 75 },
    ],
  },
  {
    title: "Database",
    icon: Database,
    color: "oklch(0.82 0.15 200)",
    skills: [{ name: "MySQL", level: 80 }],
  },
  {
    title: "Tools",
    icon: Wrench,
    color: "oklch(0.75 0.18 180)",
    skills: [
      { name: "Git", level: 80 },
      { name: "GitHub", level: 85 },
      { name: "VS Code", level: 92 },
      { name: "XAMPP", level: 80 },
    ],
  },
  {
    title: "Design",
    icon: Palette,
    color: "oklch(0.72 0.2 320)",
    skills: [
      { name: "Photoshop", level: 70 },
      { name: "CorelDRAW", level: 72 },
    ],
  },
];

export function Skills() {
  return (
    <section id="skills" className="relative px-4 py-24">
      <div className="mx-auto max-w-6xl">
        <SectionHeader
          eyebrow="Skills"
          title={<>Tools of the <span className="text-gradient">trade</span></>}
          description="A curated stack I use to bring ideas to life — from concept to deployment."
        />

        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {groups.map((g, idx) => (
            <motion.div
              key={g.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.5, delay: idx * 0.06 }}
              whileHover={{ y: -6 }}
              className="group glass rounded-2xl p-6 transition-all hover:bg-white/[0.04]"
            >
              <div className="flex items-center gap-3">
                <div
                  className="grid h-10 w-10 place-items-center rounded-xl text-primary-foreground transition-transform group-hover:rotate-6 group-hover:scale-110"
                  style={{ background: g.color, boxShadow: `0 0 20px -4px ${g.color}` }}
                >
                  <g.icon className="h-5 w-5" />
                </div>
                <h3 className="font-display text-lg font-semibold">{g.title}</h3>
              </div>
              <div className="mt-5 space-y-3">
                {g.skills.map((s) => (
                  <div key={s.name}>
                    <div className="flex items-center justify-between text-sm">
                      <span className="font-medium text-foreground">{s.name}</span>
                      <span className="font-mono text-xs text-muted-foreground">{s.level}%</span>
                    </div>
                    <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-white/5">
                      <motion.div
                        initial={{ width: 0 }}
                        whileInView={{ width: `${s.level}%` }}
                        viewport={{ once: true }}
                        transition={{ duration: 1.2, ease: "easeOut" }}
                        className="h-full rounded-full"
                        style={{ background: `linear-gradient(90deg, ${g.color}, oklch(0.82 0.15 200))` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}