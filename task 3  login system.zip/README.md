# Login & Registration System

A basic full-stack authentication system: HTML/CSS frontend, Node.js/Express backend, and a JSON file as the user database.

## Features

- Sign in / create account tabs on a single page
- Server-side validation (required fields, email format, password length, duplicate email)
- Passwords hashed with `bcryptjs` before being stored — never saved in plain text
- Session-based login using `express-session` (secure `httpOnly` cookie)
- A protected dashboard page that checks the session and redirects to login if not authenticated
- Clear, inline success/error messages on both forms
- Logout clears the session

## Project structure

```
login-system/
├── package.json
├── server.js              # Express server + API routes
├── data/
│   └── users.json         # simple JSON "database" of users
└── public/
    ├── index.html          # login + registration page
    ├── style.css
    ├── script.js           # form handling, fetch calls to the API
    └── dashboard.html      # protected page shown after login
```

## Setup

1. Make sure you have Node.js installed (v16+ recommended).
2. From the `login-system` folder, install dependencies:

   ```bash
   npm install
   ```

3. Start the server:

   ```bash
   npm start
   ```

4. Open your browser to:

   ```
   http://localhost:3000
   ```

The server runs on port 3000 by default. Set the `PORT` environment variable to change it.

## How it works

- **Register** (`POST /api/register`): validates the name, email, and password, checks that the email isn't already taken, hashes the password with bcrypt, and appends the new user to `data/users.json`.
- **Login** (`POST /api/login`): looks up the user by email, compares the submitted password against the stored hash, and if it matches, starts a session (`req.session.userId`).
- **Session check** (`GET /api/me`): used by `dashboard.html` on load to confirm the visitor is logged in; redirects to the login page otherwise.
- **Logout** (`POST /api/logout`): destroys the session and clears the cookie.

## Notes on moving this to production

This project is intentionally simple, as requested. Before using it for anything real, you'd want to:

- Swap the JSON file for a real database (MongoDB, PostgreSQL, etc.) to handle concurrent writes safely.
- Set a strong, unique `session secret` from an environment variable instead of the hardcoded placeholder in `server.js`.
- Serve the app over HTTPS and set `cookie.secure = true` in the session config.
- Add rate limiting on `/api/login` to slow down brute-force attempts.
- Add email verification if you want to confirm real email ownership.

## Switching to MongoDB (optional)

If you'd rather use MongoDB instead of the JSON file, replace the `readUsers`/`writeUsers` functions in `server.js` with calls to a MongoDB collection (using the `mongodb` or `mongoose` package), keeping the same route logic — the validation, hashing, and session handling all stay the same.
