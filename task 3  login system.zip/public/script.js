(function () {
  const tabs = document.querySelectorAll('.tab');
  const loginForm = document.getElementById('loginForm');
  const registerForm = document.getElementById('registerForm');
  const messageEl = document.getElementById('message');
  const switchNote = document.getElementById('switchNote');
  const switchToRegisterBtn = document.getElementById('switchToRegister');

  function showTab(name) {
    tabs.forEach(t => {
      const active = t.dataset.tab === name;
      t.classList.toggle('active', active);
      t.setAttribute('aria-selected', active ? 'true' : 'false');
    });
    loginForm.style.display = name === 'login' ? 'flex' : 'none';
    registerForm.style.display = name === 'register' ? 'flex' : 'none';
    hideMessage();

    if (name === 'login') {
      switchNote.innerHTML = 'Don\'t have an account? <button type="button" id="switchToRegister" class="link-btn">Create one</button>';
      document.getElementById('switchToRegister').addEventListener('click', () => showTab('register'));
    } else {
      switchNote.innerHTML = 'Already have an account? <button type="button" id="switchToLogin" class="link-btn">Sign in</button>';
      document.getElementById('switchToLogin').addEventListener('click', () => showTab('login'));
    }
  }

  tabs.forEach(tab => {
    tab.addEventListener('click', () => showTab(tab.dataset.tab));
  });
  switchToRegisterBtn.addEventListener('click', () => showTab('register'));

  function showMessage(text, type) {
    messageEl.textContent = text;
    messageEl.className = 'message ' + type;
    messageEl.style.display = 'block';
  }

  function hideMessage() {
    messageEl.style.display = 'none';
    messageEl.textContent = '';
  }

  function setLoading(form, isLoading) {
    const btn = form.querySelector('.submit-btn');
    btn.disabled = isLoading;
    btn.textContent = isLoading
      ? (form === loginForm ? 'Signing in…' : 'Creating account…')
      : (form === loginForm ? 'Sign in' : 'Create account');
  }

  async function postJSON(url, data) {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'same-origin',
      body: JSON.stringify(data)
    });
    let body;
    try {
      body = await res.json();
    } catch (e) {
      body = { success: false, message: 'Unexpected server response.' };
    }
    return { ok: res.ok, body };
  }

  // ---------- login ----------
  loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    hideMessage();

    const email = loginForm.email.value.trim();
    const password = loginForm.password.value;

    if (!email || !password) {
      showMessage('Please fill in both fields.', 'error');
      return;
    }

    setLoading(loginForm, true);
    try {
      const { ok, body } = await postJSON('/api/login', { email, password });
      if (ok && body.success) {
        showMessage('Login successful. Redirecting…', 'success');
        setTimeout(() => { window.location.href = 'dashboard.html'; }, 700);
      } else {
        showMessage(body.message || 'Login failed. Please try again.', 'error');
      }
    } catch (err) {
      showMessage('Could not reach the server. Please try again.', 'error');
    } finally {
      setLoading(loginForm, false);
    }
  });

  // ---------- register ----------
  registerForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    hideMessage();

    const name = registerForm.name.value.trim();
    const email = registerForm.email.value.trim();
    const password = registerForm.password.value;
    const confirmPassword = registerForm.confirmPassword.value;

    if (!name || !email || !password || !confirmPassword) {
      showMessage('Please fill in all fields.', 'error');
      return;
    }
    if (password.length < 6) {
      showMessage('Password must be at least 6 characters long.', 'error');
      return;
    }
    if (password !== confirmPassword) {
      showMessage('Passwords do not match.', 'error');
      return;
    }

    setLoading(registerForm, true);
    try {
      const { ok, body } = await postJSON('/api/register', { name, email, password });
      if (ok && body.success) {
        showMessage(body.message || 'Account created. You can now sign in.', 'success');
        registerForm.reset();
        setTimeout(() => showTab('login'), 900);
      } else {
        showMessage(body.message || 'Registration failed. Please try again.', 'error');
      }
    } catch (err) {
      showMessage('Could not reach the server. Please try again.', 'error');
    } finally {
      setLoading(registerForm, false);
    }
  });

  // ---------- if already logged in, skip straight to dashboard ----------
  fetch('/api/me', { credentials: 'same-origin' })
    .then(res => res.ok ? res.json() : null)
    .then(data => {
      if (data && data.success) {
        window.location.href = 'dashboard.html';
      }
    })
    .catch(() => {});
})();
